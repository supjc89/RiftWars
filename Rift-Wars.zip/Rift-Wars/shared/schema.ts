import { sql } from 'drizzle-orm';
import {
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  varchar,
  boolean,
  real,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Character classes
export const characters = pgTable("characters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  name: varchar("name", { length: 50 }).notNull(),
  class: varchar("class", { length: 20 }).notNull(), // Warrior, Mage, Rogue
  level: integer("level").notNull().default(1),
  experience: integer("experience").notNull().default(0),
  
  // Stats
  strength: integer("strength").notNull().default(10),
  agility: integer("agility").notNull().default(10),
  intelligence: integer("intelligence").notNull().default(10),
  vitality: integer("vitality").notNull().default(10),
  
  // Resources
  currentHp: integer("current_hp").notNull().default(100),
  maxHp: integer("max_hp").notNull().default(100),
  currentMp: integer("current_mp").notNull().default(50),
  maxMp: integer("max_mp").notNull().default(50),
  energy: integer("energy").notNull().default(100),
  gold: integer("gold").notNull().default(0),
  
  // Location
  currentZone: varchar("current_zone").notNull().default('nexus_district'),
  positionX: integer("position_x").notNull().default(0),
  positionY: integer("position_y").notNull().default(0),
  
  crewId: varchar("crew_id"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCharacterSchema = createInsertSchema(characters).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  name: z.string().min(3).max(50),
  class: z.enum(["Warrior", "Mage", "Rogue"]),
});

export type InsertCharacter = z.infer<typeof insertCharacterSchema>;
export type Character = typeof characters.$inferSelect;

// Equipment and inventory items
export const items = pgTable("items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  type: varchar("type").notNull(), // weapon, armor, accessory, consumable
  rarity: varchar("rarity").notNull().default('common'), // common, rare, epic, legendary
  slot: varchar("slot"), // head, chest, legs, gloves, boots, weapon, shield, accessory
  
  // Item stats
  strengthBonus: integer("strength_bonus").default(0),
  agilityBonus: integer("agility_bonus").default(0),
  intelligenceBonus: integer("intelligence_bonus").default(0),
  vitalityBonus: integer("vitality_bonus").default(0),
  damage: integer("damage").default(0),
  defense: integer("defense").default(0),
  
  // Consumable effects
  hpRestore: integer("hp_restore").default(0),
  mpRestore: integer("mp_restore").default(0),
  
  sellValue: integer("sell_value").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Item = typeof items.$inferSelect;

// Character inventory
export const inventory = pgTable("inventory", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  characterId: varchar("character_id").notNull().references(() => characters.id, { onDelete: 'cascade' }),
  itemId: varchar("item_id").notNull().references(() => items.id),
  quantity: integer("quantity").notNull().default(1),
  equipped: boolean("equipped").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export type InventoryItem = typeof inventory.$inferSelect;

// Quests
export const quests = pgTable("quests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  requiredLevel: integer("required_level").notNull().default(1),
  
  // Quest objectives
  objectiveType: varchar("objective_type").notNull(), // kill, collect, explore
  targetId: varchar("target_id"), // enemy or item id
  requiredCount: integer("required_count").notNull().default(1),
  
  // Rewards
  xpReward: integer("xp_reward").notNull().default(0),
  goldReward: integer("gold_reward").notNull().default(0),
  itemRewardId: varchar("item_reward_id").references(() => items.id),
  
  createdAt: timestamp("created_at").defaultNow(),
});

export type Quest = typeof quests.$inferSelect;

// Character quest progress
export const characterQuests = pgTable("character_quests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  characterId: varchar("character_id").notNull().references(() => characters.id, { onDelete: 'cascade' }),
  questId: varchar("quest_id").notNull().references(() => quests.id),
  progress: integer("progress").notNull().default(0),
  completed: boolean("completed").notNull().default(false),
  claimed: boolean("claimed").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export type CharacterQuest = typeof characterQuests.$inferSelect;

// Enemies/Mobs
export const enemies = pgTable("enemies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  level: integer("level").notNull(),
  hp: integer("hp").notNull(),
  damage: integer("damage").notNull(),
  defense: integer("defense").notNull(),
  xpDrop: integer("xp_drop").notNull(),
  goldDrop: integer("gold_drop").notNull(),
  zones: text("zones").array(), // zones where this enemy appears
  createdAt: timestamp("created_at").defaultNow(),
});

export type Enemy = typeof enemies.$inferSelect;

// Crews/Guilds
export const crews = pgTable("crews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 50 }).notNull().unique(),
  leaderId: varchar("leader_id").notNull(),
  description: text("description"),
  level: integer("level").notNull().default(1),
  memberCount: integer("member_count").notNull().default(1),
  maxMembers: integer("max_members").notNull().default(50),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCrewSchema = createInsertSchema(crews).omit({
  id: true,
  createdAt: true,
  memberCount: true,
}).extend({
  name: z.string().min(3).max(50),
});

export type InsertCrew = z.infer<typeof insertCrewSchema>;
export type Crew = typeof crews.$inferSelect;

// Combat logs for PvP
export const combatLogs = pgTable("combat_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  attackerId: varchar("attacker_id").notNull().references(() => characters.id),
  defenderId: varchar("defender_id").notNull().references(() => characters.id),
  attackerVictory: boolean("attacker_victory").notNull(),
  xpChange: integer("xp_change").notNull(),
  goldChange: integer("gold_change").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export type CombatLog = typeof combatLogs.$inferSelect;
