import GameHeader from '../GameHeader'

export default function GameHeaderExample() {
  return (
    <GameHeader
      characterName="CyberWarrior"
      level={42}
      hp={{ current: 850, max: 1000 }}
      mp={{ current: 420, max: 500 }}
      xp={{ current: 2750, max: 5000 }}
      gold={15240}
      energy={87}
    />
  )
}
