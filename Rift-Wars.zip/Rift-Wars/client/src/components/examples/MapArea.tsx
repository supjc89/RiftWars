import MapArea from '../MapArea'

export default function MapAreaExample() {
  return <MapArea />
}
