import InventoryItem from '../InventoryItem'

export default function InventoryItemExample() {
  return (
    <div className="flex gap-2 p-4 bg-card rounded-md">
      <InventoryItem
        item={{
          id: "i1",
          name: "Plasma Sword",
          type: "weapon",
          quantity: 1,
          rarity: "epic",
        }}
      />
      <InventoryItem
        item={{
          id: "i2",
          name: "Health Pack",
          type: "consumable",
          quantity: 5,
          rarity: "common",
        }}
      />
      <InventoryItem
        item={{
          id: "i3",
          name: "Nano Shield",
          type: "armor",
          quantity: 1,
          rarity: "legendary",
        }}
      />
    </div>
  )
}
