import CharacterPanel from '../CharacterPanel'

export default function CharacterPanelExample() {
  return (
    <CharacterPanel
      character={{
        name: "CyberWarrior",
        class: "Warrior",
        level: 42,
        stats: {
          strength: 85,
          agility: 62,
          intelligence: 45,
          vitality: 78,
        },
      }}
    />
  )
}
