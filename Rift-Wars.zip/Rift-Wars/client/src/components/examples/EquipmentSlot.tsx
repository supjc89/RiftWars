import EquipmentSlot from '../EquipmentSlot'

export default function EquipmentSlotExample() {
  return (
    <div className="flex gap-4 p-4 bg-card rounded-md">
      <EquipmentSlot slot="weapon" equipped={{ name: "Plasma Sword" }} />
      <EquipmentSlot slot="shield" />
      <EquipmentSlot slot="chest" equipped={{ name: "Nano Armor" }} />
      <EquipmentSlot slot="head" />
    </div>
  )
}
