import StatBar from '../StatBar'

export default function StatBarExample() {
  return (
    <div className="space-y-4 p-4 bg-card rounded-md w-64">
      <StatBar label="HP" current={850} max={1000} color="health" />
      <StatBar label="MP" current={420} max={500} color="mana" />
      <StatBar label="XP" current={2750} max={5000} color="experience" />
    </div>
  )
}
