import InventoryQuestPanel from '../InventoryQuestPanel'

export default function InventoryQuestPanelExample() {
  return <InventoryQuestPanel />
}
