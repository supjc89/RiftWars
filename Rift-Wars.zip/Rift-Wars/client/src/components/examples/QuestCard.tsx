import QuestCard from '../QuestCard'

export default function QuestCardExample() {
  return (
    <div className="space-y-4 w-80 p-4">
      <QuestCard
        quest={{
          id: "q1",
          title: "Defeat Rogue Droids",
          description: "Clear the industrial sector of hostile droids",
          level: 40,
          progress: { current: 7, required: 10 },
          rewards: { xp: 2500, gold: 500 },
          completed: false,
        }}
      />
      <QuestCard
        quest={{
          id: "q2",
          title: "Retrieve Data Core",
          description: "Locate and secure the stolen data core from the hacker den",
          level: 42,
          progress: { current: 1, required: 1 },
          rewards: { xp: 5000, gold: 1200 },
          completed: true,
        }}
      />
    </div>
  )
}
