import CombatModal from '../CombatModal'
import { useState } from 'react'
import { Button } from '@/components/ui/button'

export default function CombatModalExample() {
  const [open, setOpen] = useState(false)

  return (
    <div className="p-4">
      <Button onClick={() => setOpen(true)}>Open Combat</Button>
      <CombatModal
        open={open}
        onOpenChange={setOpen}
        enemy={{
          name: "Corrupted AI",
          level: 40,
          hp: { current: 850, max: 1200 },
        }}
      />
    </div>
  )
}
