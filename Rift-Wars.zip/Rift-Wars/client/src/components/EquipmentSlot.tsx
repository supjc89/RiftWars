import { Sword, Shield, User, Shirt, Footprints, Hand, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

interface EquipmentSlotProps {
  slot: "head" | "chest" | "legs" | "gloves" | "boots" | "weapon" | "shield" | "accessory";
  equipped?: {
    name: string;
    icon?: string;
  };
  onClick?: () => void;
}

const slotIcons = {
  head: User,
  chest: Shirt,
  legs: Footprints,
  gloves: Hand,
  boots: Footprints,
  weapon: Sword,
  shield: Shield,
  accessory: Sparkles,
};

export default function EquipmentSlot({ slot, equipped, onClick }: EquipmentSlotProps) {
  const Icon = slotIcons[slot];
  
  return (
    <Button
      variant={equipped ? "secondary" : "outline"}
      className="h-16 w-16 p-2 hover-elevate active-elevate-2"
      onClick={() => {
        onClick?.();
        console.log(`${slot} slot clicked`);
      }}
      data-testid={`equipment-slot-${slot}`}
    >
      <div className="flex flex-col items-center justify-center">
        <Icon className="h-6 w-6" />
        {equipped && (
          <span className="text-[10px] mt-1 truncate w-full text-center">
            {equipped.name}
          </span>
        )}
      </div>
    </Button>
  );
}
