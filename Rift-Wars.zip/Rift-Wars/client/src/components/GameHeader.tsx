import { Coins, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import StatBar from "./StatBar";
import ThemeToggle from "./ThemeToggle";

interface GameHeaderProps {
  characterName: string;
  level: number;
  hp: { current: number; max: number };
  mp: { current: number; max: number };
  xp: { current: number; max: number };
  gold: number;
  energy: number;
}

export default function GameHeader({
  characterName,
  level,
  hp,
  mp,
  xp,
  gold,
  energy,
}: GameHeaderProps) {
  return (
    <header className="border-b bg-card p-4" data-testid="game-header">
      <div className="max-w-screen-2xl mx-auto">
        <div className="flex items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold uppercase tracking-wider" data-testid="text-character-name">
                {characterName}
              </h1>
              <Badge variant="secondary" className="mt-1" data-testid="badge-level">
                Level {level}
              </Badge>
            </div>
          </div>

          <div className="flex-1 max-w-md space-y-2">
            <StatBar label="HP" current={hp.current} max={hp.max} color="health" />
            <StatBar label="MP" current={mp.current} max={mp.max} color="mana" />
            <StatBar label="XP" current={xp.current} max={xp.max} color="experience" />
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2" data-testid="currency-gold">
              <Coins className="h-5 w-5 text-chart-4" />
              <span className="font-mono text-lg tabular-nums">{gold.toLocaleString()}</span>
            </div>
            <div className="flex items-center gap-2" data-testid="currency-energy">
              <Zap className="h-5 w-5 text-primary" />
              <span className="font-mono text-lg tabular-nums">{energy}</span>
            </div>
            <ThemeToggle />
          </div>
        </div>
      </div>
    </header>
  );
}
