import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Sword, Shield, Zap, Flag } from "lucide-react";
import { useState } from "react";

interface CombatModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  enemy: {
    name: string;
    level: number;
    hp: { current: number; max: number };
  };
}

export default function CombatModal({ open, onOpenChange, enemy }: CombatModalProps) {
  const [combatLog, setCombatLog] = useState<string[]>([
    "Battle initiated!",
    `You encounter ${enemy.name} (Level ${enemy.level})`,
  ]);

  const handleAttack = () => {
    const damage = Math.floor(Math.random() * 50) + 20;
    setCombatLog((prev) => [...prev, `You attack for ${damage} damage!`]);
    console.log('Attack action');
  };

  const handleSkill = () => {
    setCombatLog((prev) => [...prev, "You use Plasma Strike!"]);
    console.log('Skill action');
  };

  const handleDefend = () => {
    setCombatLog((prev) => [...prev, "You take a defensive stance."]);
    console.log('Defend action');
  };

  const handleFlee = () => {
    setCombatLog((prev) => [...prev, "You attempt to flee..."]);
    console.log('Flee action');
    setTimeout(() => onOpenChange(false), 1000);
  };

  const hpPercent = (enemy.hp.current / enemy.hp.max) * 100;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl" data-testid="combat-modal">
        <DialogHeader>
          <DialogTitle className="text-2xl uppercase tracking-wider">Combat Encounter</DialogTitle>
          <DialogDescription>Defeat your enemy to claim rewards</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <div className="bg-muted/50 p-4 rounded-md space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold" data-testid="text-enemy-name">{enemy.name}</h3>
              <span className="text-sm text-muted-foreground">Level {enemy.level}</span>
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>HP</span>
                <span className="font-mono" data-testid="text-enemy-hp">
                  {enemy.hp.current}/{enemy.hp.max}
                </span>
              </div>
              <div className="relative">
                <Progress value={hpPercent} className="h-3" />
                <div
                  className="absolute top-0 left-0 h-3 rounded-full bg-chart-3 transition-all"
                  style={{ width: `${hpPercent}%` }}
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2">
            <Button 
              onClick={handleAttack} 
              className="flex flex-col gap-1 h-auto py-3"
              data-testid="button-combat-attack"
            >
              <Sword className="h-5 w-5" />
              <span className="text-xs">Attack</span>
            </Button>
            <Button
              onClick={handleSkill}
              variant="secondary"
              className="flex flex-col gap-1 h-auto py-3"
              data-testid="button-combat-skill"
            >
              <Zap className="h-5 w-5" />
              <span className="text-xs">Skill</span>
            </Button>
            <Button
              onClick={handleDefend}
              variant="outline"
              className="flex flex-col gap-1 h-auto py-3"
              data-testid="button-combat-defend"
            >
              <Shield className="h-5 w-5" />
              <span className="text-xs">Defend</span>
            </Button>
            <Button
              onClick={handleFlee}
              variant="destructive"
              className="flex flex-col gap-1 h-auto py-3"
              data-testid="button-combat-flee"
            >
              <Flag className="h-5 w-5" />
              <span className="text-xs">Flee</span>
            </Button>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wide mb-2">Combat Log</h4>
            <ScrollArea className="h-40 bg-muted/30 rounded-md p-3">
              <div className="space-y-1 font-mono text-xs" data-testid="combat-log">
                {combatLog.map((log, i) => (
                  <div key={i}>{log}</div>
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
