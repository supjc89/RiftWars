import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Zap, Brain, Heart, Target } from "lucide-react";
import EquipmentSlot from "./EquipmentSlot";

interface CharacterPanelProps {
  character: {
    name: string;
    class: string;
    level: number;
    stats: {
      strength: number;
      agility: number;
      intelligence: number;
      vitality: number;
    };
  };
}

export default function CharacterPanel({ character }: CharacterPanelProps) {
  return (
    <Card className="w-72 h-full" data-testid="character-panel">
      <CardHeader>
        <CardTitle className="text-lg uppercase tracking-wider">Character</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-col items-center gap-2">
          <div className="h-32 w-32 rounded-md bg-muted flex items-center justify-center border-2 border-primary/20">
            <User className="h-20 w-20 text-muted-foreground" />
          </div>
          <div className="text-center">
            <h3 className="font-bold text-lg" data-testid="text-character-name">{character.name}</h3>
            <Badge variant="outline" data-testid="badge-class">{character.class}</Badge>
          </div>
        </div>

        <div className="space-y-3">
          <h4 className="text-sm font-semibold uppercase tracking-wide">Stats</h4>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md" data-testid="stat-strength">
              <Target className="h-4 w-4 text-destructive" />
              <div>
                <div className="text-xs text-muted-foreground">STR</div>
                <div className="font-mono font-bold">{character.stats.strength}</div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md" data-testid="stat-agility">
              <Zap className="h-4 w-4 text-primary" />
              <div>
                <div className="text-xs text-muted-foreground">AGI</div>
                <div className="font-mono font-bold">{character.stats.agility}</div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md" data-testid="stat-intelligence">
              <Brain className="h-4 w-4 text-accent" />
              <div>
                <div className="text-xs text-muted-foreground">INT</div>
                <div className="font-mono font-bold">{character.stats.intelligence}</div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md" data-testid="stat-vitality">
              <Heart className="h-4 w-4 text-chart-3" />
              <div>
                <div className="text-xs text-muted-foreground">VIT</div>
                <div className="font-mono font-bold">{character.stats.vitality}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h4 className="text-sm font-semibold uppercase tracking-wide">Equipment</h4>
          <div className="grid grid-cols-4 gap-2">
            <EquipmentSlot slot="head" />
            <EquipmentSlot slot="chest" equipped={{ name: "Armor" }} />
            <EquipmentSlot slot="legs" />
            <EquipmentSlot slot="gloves" />
            <EquipmentSlot slot="boots" />
            <EquipmentSlot slot="weapon" equipped={{ name: "Sword" }} />
            <EquipmentSlot slot="shield" />
            <EquipmentSlot slot="accessory" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
