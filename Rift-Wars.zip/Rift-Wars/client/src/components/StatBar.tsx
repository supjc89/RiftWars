import { Progress } from "@/components/ui/progress";

interface StatBarProps {
  label: string;
  current: number;
  max: number;
  color: "health" | "mana" | "experience";
}

export default function StatBar({ label, current, max, color }: StatBarProps) {
  const percentage = (current / max) * 100;
  
  const colorClasses = {
    health: "bg-chart-3",
    mana: "bg-chart-1", 
    experience: "bg-chart-2"
  };

  return (
    <div className="space-y-1" data-testid={`stat-bar-${label.toLowerCase()}`}>
      <div className="flex justify-between items-center">
        <span className="text-xs font-semibold uppercase tracking-wide">{label}</span>
        <span className="text-xs font-mono tabular-nums">
          {current}/{max}
        </span>
      </div>
      <div className="relative">
        <Progress value={percentage} className="h-2" />
        <div 
          className={`absolute top-0 left-0 h-2 rounded-full transition-all ${colorClasses[color]}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
