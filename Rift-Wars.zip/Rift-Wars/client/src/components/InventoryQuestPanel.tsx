import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Package, ScrollText, Users } from "lucide-react";
import InventoryItem from "./InventoryItem";
import QuestCard from "./QuestCard";
import { Badge } from "@/components/ui/badge";

export default function InventoryQuestPanel() {
  //todo: remove mock functionality
  const mockInventory = [
    { id: "i1", name: "Plasma Sword", type: "weapon" as const, quantity: 1, rarity: "epic" as const },
    { id: "i2", name: "Health Pack", type: "consumable" as const, quantity: 12, rarity: "common" as const },
    { id: "i3", name: "Nano Shield", type: "armor" as const, quantity: 1, rarity: "rare" as const },
    { id: "i4", name: "Energy Cell", type: "consumable" as const, quantity: 8, rarity: "common" as const },
    { id: "i5", name: "Cyber Ring", type: "accessory" as const, quantity: 1, rarity: "legendary" as const },
  ];

  const mockQuests = [
    {
      id: "q1",
      title: "Defeat Rogue Droids",
      description: "Clear the industrial sector of hostile droids",
      level: 40,
      progress: { current: 7, required: 10 },
      rewards: { xp: 2500, gold: 500 },
      completed: false,
    },
    {
      id: "q2",
      title: "Retrieve Data Core",
      description: "Locate and secure the stolen data core",
      level: 42,
      progress: { current: 1, required: 1 },
      rewards: { xp: 5000, gold: 1200 },
      completed: true,
    },
  ];

  const mockCrewMembers = [
    { name: "NovaStrike", level: 45, class: "Mage", online: true },
    { name: "IronFist", level: 43, class: "Warrior", online: true },
    { name: "ShadowByte", level: 41, class: "Rogue", online: false },
    { name: "TechPriest", level: 44, class: "Mage", online: true },
  ];

  return (
    <Card className="w-80 h-full" data-testid="inventory-quest-panel">
      <CardHeader>
        <CardTitle className="text-lg uppercase tracking-wider">Game Info</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <Tabs defaultValue="inventory" className="w-full">
          <TabsList className="w-full grid grid-cols-3 mx-4" style={{ width: 'calc(100% - 2rem)' }}>
            <TabsTrigger value="inventory" data-testid="tab-inventory">
              <Package className="h-4 w-4 mr-2" />
              Items
            </TabsTrigger>
            <TabsTrigger value="quests" data-testid="tab-quests">
              <ScrollText className="h-4 w-4 mr-2" />
              Quests
            </TabsTrigger>
            <TabsTrigger value="crew" data-testid="tab-crew">
              <Users className="h-4 w-4 mr-2" />
              Crew
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inventory" className="px-4 pb-4">
            <ScrollArea className="h-[500px]">
              <div className="grid grid-cols-4 gap-2">
                {mockInventory.map((item) => (
                  <InventoryItem key={item.id} item={item} />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="quests" className="px-4 pb-4">
            <ScrollArea className="h-[500px]">
              <div className="space-y-3">
                {mockQuests.map((quest) => (
                  <QuestCard key={quest.id} quest={quest} />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="crew" className="px-4 pb-4">
            <ScrollArea className="h-[500px]">
              <div className="space-y-2">
                {mockCrewMembers.map((member) => (
                  <div
                    key={member.name}
                    className="flex items-center justify-between p-3 bg-muted/50 rounded-md hover-elevate"
                    data-testid={`crew-member-${member.name}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`h-2 w-2 rounded-full ${member.online ? 'bg-chart-3' : 'bg-muted-foreground'}`} />
                      <div>
                        <div className="font-semibold">{member.name}</div>
                        <div className="text-xs text-muted-foreground">{member.class}</div>
                      </div>
                    </div>
                    <Badge variant="outline" data-testid={`crew-level-${member.name}`}>
                      Lv {member.level}
                    </Badge>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
