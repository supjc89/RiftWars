import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sword, Shield, Sparkles, Pill } from "lucide-react";

interface InventoryItemProps {
  item: {
    id: string;
    name: string;
    type: "weapon" | "armor" | "accessory" | "consumable";
    quantity: number;
    rarity: "common" | "rare" | "epic" | "legendary";
  };
  onClick?: () => void;
}

const itemIcons = {
  weapon: Sword,
  armor: Shield,
  accessory: Sparkles,
  consumable: Pill,
};

const rarityColors = {
  common: "bg-muted",
  rare: "bg-chart-1/20 border-chart-1/50",
  epic: "bg-accent/20 border-accent/50",
  legendary: "bg-chart-4/20 border-chart-4/50",
};

export default function InventoryItem({ item, onClick }: InventoryItemProps) {
  const Icon = itemIcons[item.type];

  return (
    <Button
      variant="outline"
      className={`h-16 w-16 p-2 relative hover-elevate active-elevate-2 ${rarityColors[item.rarity]}`}
      onClick={() => {
        onClick?.();
        console.log('Item clicked:', item.name);
      }}
      data-testid={`inventory-item-${item.id}`}
    >
      <div className="flex flex-col items-center justify-center">
        <Icon className="h-6 w-6" />
        {item.quantity > 1 && (
          <Badge 
            variant="secondary" 
            className="absolute bottom-1 right-1 h-4 px-1 text-[10px] min-w-4"
            data-testid={`item-quantity-${item.id}`}
          >
            {item.quantity}
          </Badge>
        )}
      </div>
    </Button>
  );
}
