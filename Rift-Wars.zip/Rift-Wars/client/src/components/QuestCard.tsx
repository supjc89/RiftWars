import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, Coins, Sparkles } from "lucide-react";

interface QuestCardProps {
  quest: {
    id: string;
    title: string;
    description: string;
    level: number;
    progress: { current: number; required: number };
    rewards: {
      xp: number;
      gold: number;
    };
    completed: boolean;
  };
}

export default function QuestCard({ quest }: QuestCardProps) {
  const progressPercent = (quest.progress.current / quest.progress.required) * 100;

  return (
    <Card className="hover-elevate" data-testid={`quest-card-${quest.id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-base">{quest.title}</CardTitle>
          <Badge variant="secondary" className="shrink-0" data-testid="badge-quest-level">
            Lv {quest.level}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground">{quest.description}</p>
        
        <div className="space-y-1">
          <div className="flex justify-between items-center text-xs">
            <span>Progress</span>
            <span className="font-mono" data-testid="text-quest-progress">
              {quest.progress.current}/{quest.progress.required}
            </span>
          </div>
          <Progress value={progressPercent} className="h-2" />
        </div>

        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1" data-testid="reward-xp">
            <Sparkles className="h-4 w-4 text-chart-2" />
            <span className="font-mono">{quest.rewards.xp}</span>
          </div>
          <div className="flex items-center gap-1" data-testid="reward-gold">
            <Coins className="h-4 w-4 text-chart-4" />
            <span className="font-mono">{quest.rewards.gold}</span>
          </div>
        </div>

        {quest.completed ? (
          <Button className="w-full" variant="default" data-testid="button-quest-claim">
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Claim Reward
          </Button>
        ) : (
          <Button 
            className="w-full" 
            variant="secondary"
            onClick={() => console.log('Track quest:', quest.id)}
            data-testid="button-quest-track"
          >
            Track Quest
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
