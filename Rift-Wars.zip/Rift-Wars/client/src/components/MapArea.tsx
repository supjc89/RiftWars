import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, MapPin, Swords, User } from "lucide-react";
import { useState } from "react";
import CombatModal from "./CombatModal";

export default function MapArea() {
  const [zone] = useState("Nexus District");
  const [combatOpen, setCombatOpen] = useState(false);

  const handleMove = (direction: string) => {
    console.log('Move:', direction);
  };

  const handleEncounter = (type: string) => {
    console.log('Encounter:', type);
    if (type === 'enemy') {
      setCombatOpen(true);
    }
  };

  return (
    <>
      <Card className="flex-1 h-full" data-testid="map-area">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg uppercase tracking-wider flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              {zone}
            </CardTitle>
            <Badge variant="outline" data-testid="badge-zone-level">Zone Level: 38-42</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-8 gap-2 aspect-square max-w-2xl mx-auto">
            {Array.from({ length: 64 }).map((_, i) => {
              const hasEnemy = i === 18 || i === 42;
              const hasNPC = i === 10;
              const isPlayer = i === 28;

              return (
                <Button
                  key={i}
                  variant={isPlayer ? "default" : "outline"}
                  className={`aspect-square p-0 hover-elevate active-elevate-2 ${
                    hasEnemy ? 'bg-destructive/20 border-destructive/50' : ''
                  } ${hasNPC ? 'bg-primary/20 border-primary/50' : ''}`}
                  onClick={() => {
                    if (hasEnemy) handleEncounter('enemy');
                    if (hasNPC) handleEncounter('npc');
                  }}
                  data-testid={`map-tile-${i}`}
                >
                  {isPlayer && <User className="h-4 w-4" />}
                  {hasEnemy && <Swords className="h-4 w-4 text-destructive" />}
                  {hasNPC && <User className="h-4 w-4 text-primary" />}
                </Button>
              );
            })}
          </div>

          <div className="flex justify-center">
            <div className="grid grid-cols-3 gap-2 w-40">
              <div />
              <Button
                variant="secondary"
                size="icon"
                onClick={() => handleMove('north')}
                data-testid="button-move-north"
              >
                <ArrowUp className="h-4 w-4" />
              </Button>
              <div />
              <Button
                variant="secondary"
                size="icon"
                onClick={() => handleMove('west')}
                data-testid="button-move-west"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center justify-center">
                <MapPin className="h-5 w-5 text-muted-foreground" />
              </div>
              <Button
                variant="secondary"
                size="icon"
                onClick={() => handleMove('east')}
                data-testid="button-move-east"
              >
                <ArrowRight className="h-4 w-4" />
              </Button>
              <div />
              <Button
                variant="secondary"
                size="icon"
                onClick={() => handleMove('south')}
                data-testid="button-move-south"
              >
                <ArrowDown className="h-4 w-4" />
              </Button>
              <div />
            </div>
          </div>

          <div className="bg-muted/30 p-4 rounded-md">
            <h4 className="text-sm font-semibold uppercase tracking-wide mb-2">Zone Info</h4>
            <p className="text-sm text-muted-foreground">
              A dangerous sector filled with rogue AI and corrupted droids. Valuable loot and data cores can be found here.
            </p>
          </div>
        </CardContent>
      </Card>

      <CombatModal
        open={combatOpen}
        onOpenChange={setCombatOpen}
        enemy={{
          name: "Corrupted AI",
          level: 40,
          hp: { current: 1200, max: 1200 },
        }}
      />
    </>
  );
}
