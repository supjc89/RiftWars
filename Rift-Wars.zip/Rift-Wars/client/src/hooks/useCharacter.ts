import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Character, InsertCharacter } from "@shared/schema";

export function useCharacters() {
  return useQuery<Character[]>({
    queryKey: ["/api/characters"],
  });
}

export function useCharacter(id: string | null) {
  return useQuery<Character>({
    queryKey: ["/api/characters", id],
    enabled: !!id,
  });
}

export function useCreateCharacter() {
  return useMutation({
    mutationFn: async (data: InsertCharacter) => {
      return await apiRequest("/api/characters", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/characters"] });
    },
  });
}

export function useUpdateCharacter(id: string) {
  return useMutation({
    mutationFn: async (data: Partial<Character>) => {
      return await apiRequest(`/api/characters/${id}`, "PATCH", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/characters"] });
      queryClient.invalidateQueries({ queryKey: ["/api/characters", id] });
    },
  });
}
