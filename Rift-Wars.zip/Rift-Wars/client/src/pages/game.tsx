import GameHeader from "@/components/GameHeader";
import CharacterPanel from "@/components/CharacterPanel";
import MapArea from "@/components/MapArea";
import InventoryQuestPanel from "@/components/InventoryQuestPanel";
import { useCharacter } from "@/hooks/useCharacter";

export default function Game() {
  const params = new URLSearchParams(window.location.search);
  const characterId = params.get("character");
  
  const { data: character, isLoading } = useCharacter(characterId);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading character...</p>
      </div>
    );
  }

  if (!character) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Character not found</p>
      </div>
    );
  }

  const xpNeeded = character.level * 1000;

  return (
    <div className="flex flex-col h-screen">
      <GameHeader
        characterName={character.name}
        level={character.level}
        hp={{ current: character.currentHp, max: character.maxHp }}
        mp={{ current: character.currentMp, max: character.maxMp }}
        xp={{ current: character.experience, max: xpNeeded }}
        gold={character.gold}
        energy={character.energy}
      />
      
      <div className="flex-1 flex gap-4 p-4 max-w-screen-2xl mx-auto w-full overflow-hidden">
        <CharacterPanel
          character={{
            name: character.name,
            class: character.class,
            level: character.level,
            stats: {
              strength: character.strength,
              agility: character.agility,
              intelligence: character.intelligence,
              vitality: character.vitality,
            },
          }}
        />
        <MapArea />
        <InventoryQuestPanel />
      </div>
    </div>
  );
}
