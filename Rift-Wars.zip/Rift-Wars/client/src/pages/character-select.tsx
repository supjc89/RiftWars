import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useCharacters, useCreateCharacter } from "@/hooks/useCharacter";
import { Sword, Wand2, Zap, Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

const classIcons = {
  Warrior: Sword,
  Mage: Wand2,
  Rogue: Zap,
};

export default function CharacterSelect() {
  const { data: characters, isLoading } = useCharacters();
  const createCharacter = useCreateCharacter();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [selectedClass, setSelectedClass] = useState<"Warrior" | "Mage" | "Rogue">("Warrior");

  const handleCreate = async () => {
    if (!name.trim()) {
      toast({
        title: "Error",
        description: "Character name is required",
        variant: "destructive",
      });
      return;
    }

    try {
      await createCharacter.mutateAsync({
        name: name.trim(),
        class: selectedClass,
        userId: "",
      });

      toast({
        title: "Success",
        description: "Character created successfully!",
      });

      setOpen(false);
      setName("");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create character",
        variant: "destructive",
      });
    }
  };

  const handleSelectCharacter = (characterId: string) => {
    window.location.href = `/?character=${characterId}`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading characters...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b bg-card p-4">
        <div className="max-w-screen-xl mx-auto flex items-center justify-between">
          <h1 className="text-3xl font-bold uppercase tracking-wider">
            <span className="text-primary">Nexus</span> Wars
          </h1>
          <Button
            variant="outline"
            onClick={() => (window.location.href = "/api/logout")}
            data-testid="button-logout"
          >
            Logout
          </Button>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-8">
        <div className="max-w-4xl w-full space-y-8">
          <div className="text-center">
            <h2 className="text-4xl font-bold uppercase tracking-wider mb-2">Select Character</h2>
            <p className="text-muted-foreground">Choose a character to continue your journey</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {characters?.map((character) => {
              const Icon = classIcons[character.class as keyof typeof classIcons];
              return (
                <Card
                  key={character.id}
                  className="hover-elevate active-elevate-2 cursor-pointer"
                  onClick={() => handleSelectCharacter(character.id)}
                  data-testid={`character-card-${character.id}`}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>{character.name}</CardTitle>
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{character.class}</Badge>
                      <Badge>Lv {character.level}</Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <div>XP: {character.experience.toLocaleString()}</div>
                      <div>Gold: {character.gold.toLocaleString()}</div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Card className="hover-elevate active-elevate-2 cursor-pointer border-dashed flex items-center justify-center min-h-[200px]">
                  <CardContent className="text-center">
                    <Plus className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                    <p className="font-semibold">Create New Character</p>
                  </CardContent>
                </Card>
              </DialogTrigger>
              <DialogContent data-testid="dialog-create-character">
                <DialogHeader>
                  <DialogTitle>Create New Character</DialogTitle>
                  <DialogDescription>Choose your class and enter your character name</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Character Name</Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Enter name..."
                      data-testid="input-character-name"
                    />
                  </div>

                  <div>
                    <Label>Class</Label>
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      {(["Warrior", "Mage", "Rogue"] as const).map((cls) => {
                        const Icon = classIcons[cls];
                        return (
                          <Button
                            key={cls}
                            variant={selectedClass === cls ? "default" : "outline"}
                            className="flex flex-col gap-2 h-auto py-4"
                            onClick={() => setSelectedClass(cls)}
                            data-testid={`button-class-${cls.toLowerCase()}`}
                          >
                            <Icon className="h-6 w-6" />
                            <span>{cls}</span>
                          </Button>
                        );
                      })}
                    </div>
                  </div>

                  <Button
                    className="w-full"
                    onClick={handleCreate}
                    disabled={createCharacter.isPending}
                    data-testid="button-create-character"
                  >
                    {createCharacter.isPending ? "Creating..." : "Create Character"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </main>
    </div>
  );
}
