import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Swords, Users, Zap, Target } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b bg-card p-4">
        <div className="max-w-screen-xl mx-auto flex items-center justify-between">
          <h1 className="text-3xl font-bold uppercase tracking-wider">
            <span className="text-primary">Nexus</span> Wars
          </h1>
          <Button
            onClick={() => (window.location.href = "/api/login")}
            size="lg"
            data-testid="button-login"
          >
            Enter Game
          </Button>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-8">
        <div className="max-w-4xl w-full space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-5xl font-bold uppercase tracking-wider">
              Join the Battle for Control
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              A browser-based sci-fi MMORPG featuring character progression, intense PvP combat, epic quests, and guild raids. No download required.
            </p>
            <Button
              onClick={() => (window.location.href = "/api/login")}
              size="lg"
              className="text-lg px-8 py-6"
              data-testid="button-play-now"
            >
              Play Now - Free
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader>
                <Target className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Character Classes</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Choose from Warrior, Mage, or Rogue. Build your character with unique stats and abilities.
                </CardDescription>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Swords className="h-8 w-8 text-primary mb-2" />
                <CardTitle>PvE & PvP Combat</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Battle AI enemies for loot and XP. Challenge other players in strategic PvP duels.
                </CardDescription>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Zap className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Quest System</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Complete epic quests to earn rewards, unlock new zones, and progress your character.
                </CardDescription>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Users className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Form Crews</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Create or join guilds to coordinate raids, dominate PvP, and conquer the Nexus.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <footer className="border-t bg-card p-6">
        <div className="max-w-screen-xl mx-auto text-center text-sm text-muted-foreground">
          <p>&copy; 2025 Nexus Wars. A browser-based MMORPG experience.</p>
        </div>
      </footer>
    </div>
  );
}
