# Design Guidelines: Outwar-Inspired Browser MMORPG

## Design Approach

**Selected Approach:** Reference-Based (Gaming UI)

**Primary References:**
- Path of Exile (complex stat systems, dark fantasy RPG UI)
- RuneScape (browser-based MMORPG interfaces)
- Warframe (sci-fi aesthetic, modular UI panels)
- Diablo III (inventory management, skill trees)

**Core Principle:** Retro sci-fi gaming aesthetic with information-dense layouts optimized for long play sessions. Prioritize functionality and readability over minimalism while maintaining visual cohesion through consistent panel structures and typography hierarchy.

---

## Typography System

**Font Families:**
- Primary UI: "Rajdhani" (Google Fonts) - Bold, geometric, sci-fi aesthetic for headings and stats
- Body/Stats: "Share Tech Mono" (Google Fonts) - Monospace for numbers, stats, combat logs
- Fallback: System sans-serif

**Hierarchy:**
- Page Headers: text-4xl font-bold uppercase tracking-wide
- Section Headers: text-2xl font-semibold uppercase
- Panel Titles: text-lg font-bold uppercase tracking-wider
- Stats/Numbers: text-sm font-mono tabular-nums
- Body Text: text-base font-medium
- Small Labels: text-xs font-semibold uppercase tracking-wide

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, and 8
- Component padding: p-4 or p-6
- Section margins: m-4, m-6, m-8
- Gap spacing: gap-4, gap-6
- Icon sizes: h-6 w-6, h-8 w-8

**Grid Structure:**
- Main game viewport: Fixed container max-w-screen-2xl mx-auto
- Three-panel layout for main game screen:
  - Left sidebar (character/stats): w-72 fixed
  - Center content (map/combat): flex-1
  - Right sidebar (inventory/quests): w-80 fixed
- Responsive: Stack panels vertically on mobile (< lg breakpoint)

**Panel Architecture:**
- All game panels use consistent border treatment and subtle backdrop
- Panel headers with icon + title
- Scrollable content areas with max-height constraints
- Sticky panel headers where appropriate

---

## Component Library

### Navigation & Header
- Top bar spanning full width with game logo, character name, level indicator
- Primary stats (HP/MP/XP) displayed as horizontal bars with numerical overlays
- Currency/resources displayed as icon + number badges
- Settings/logout buttons aligned right

### Character Panel (Left Sidebar)
- Avatar display area (128x128 square)
- Character name + class + level
- Primary stats in 2-column grid: Strength, Agility, Intelligence, Vitality
- Equipment paper doll with 8 slots (head, chest, legs, gloves, boots, weapon, shield, accessory)
- Each slot clickable with hover state showing equipped item

### Map/Combat Area (Center)
- Zone name header with breadcrumb navigation
- Grid-based map using 8x8 or 10x10 tiles
- Clickable movement indicators (arrows/tiles)
- NPC markers with quest indicators (! or ?)
- Combat encounter overlay modal (when engaged):
  - Enemy display with HP bar
  - Combat action buttons (Attack, Skill, Defend, Flee) in horizontal row
  - Combat log scrolling text area below actions
  - Loot results display on victory

### Inventory/Quest Panel (Right Sidebar)
- Tabbed interface switching between:
  - Inventory: Grid layout (6 columns) of item slots with stack counts
  - Quests: Accordion-style quest list with expandable details
  - Skills: Tree or list view of available/unlocked skills
  - Crew: List of guild members with online status indicators

### Quest Display
- Quest title with level requirement badge
- Objective list with progress indicators (3/10 kills)
- Reward preview (XP icon + amount, gold icon + amount, item icons)
- Accept/Abandon buttons

### PvP Challenge Modal
- Two-column layout: Your stats vs Opponent stats
- Stake amount input (gold/XP)
- Challenge/Accept/Decline action buttons
- Combat result display with XP/gold changes

### Crew/Guild Interface
- Guild name header with member count
- Member list showing: Avatar, Name, Level, Class, Online status
- Guild chat area with message input
- Raid scheduling panel with boss selection dropdown

---

## UI Patterns

**Buttons:**
- Primary actions: Rounded borders, uppercase text, font-bold
- Secondary actions: Outlined style with transparent background
- Icon buttons: Square with centered icon (p-2)
- Size variants: py-2 px-4 (default), py-3 px-6 (large), py-1 px-3 (small)

**Stats Display:**
- Use horizontal progress bars for HP/MP/XP with percentage fill
- Numerical values overlaid as white text with text-shadow
- Status effects as icon badges with tooltips

**Data Tables:**
- Leaderboards and rankings use striped rows (odd row subtle backdrop)
- Column headers with sort indicators
- Highlight current player row

**Modals/Overlays:**
- Centered overlay with max-w-2xl
- Backdrop blur effect
- Close button (X) in top-right corner
- Action buttons in footer (right-aligned)

**Notifications:**
- Toast notifications slide in from top-right
- Icon + message + timestamp
- Auto-dismiss after 5 seconds with progress bar

---

## Animations

**Minimal & Purposeful:**
- Hover states: Subtle brightness increase (0.1s transition)
- Combat damage numbers: Float upward with fade (0.5s)
- Level up: Brief pulsing glow effect (1s)
- Panel transitions: Slide in/out (0.2s ease-in-out)
- NO scroll-triggered animations
- NO complex background animations

---

## Images

**Hero Image:** None - game launches directly into interface

**Image Requirements:**

1. **Character Avatars** (128x128px):
   - Placeholder sci-fi portraits for each class
   - Use placeholder service or icon-based avatars

2. **Item Icons** (48x48px):
   - Weapons, armor, consumables
   - Use icon libraries initially, can be replaced with custom sprites

3. **Map Tiles** (64x64px):
   - Ground textures, walls, obstacles
   - Simple geometric patterns acceptable for MVP

4. **NPC/Monster Sprites** (96x96px):
   - Enemy encounter displays
   - Quest giver NPCs

5. **Skill Icons** (32x32px):
   - Ability representations in skill tree
   - Combat action buttons

**Image Placement:**
- Equipment slots: Center-aligned item icons with empty state border
- Inventory grid: Item icons with quantity badge overlay (bottom-right)
- Combat area: Enemy sprite positioned above combat log
- Quest panel: Small icon next to quest title indicating quest type

---

## Accessibility

- All interactive elements minimum 44x44px touch target
- Form inputs with visible labels (not just placeholders)
- Keyboard navigation through all UI panels (Tab order: Left → Center → Right)
- Focus states with visible outline (ring-2 ring-offset-2)
- ARIA labels for icon-only buttons
- Screen reader announcements for combat events and level ups
- Sufficient contrast ratios maintained throughout (text on dark backgrounds)

---

## Responsive Breakpoints

- **Mobile (< md):** Single column stack, collapsible sidebars accessed via menu
- **Tablet (md-lg):** Two-column layout (combine left sidebar with center)
- **Desktop (lg+):** Full three-panel layout as described