import {
  users,
  characters,
  items,
  inventory,
  quests,
  characterQuests,
  enemies,
  crews,
  combatLogs,
  type User,
  type UpsertUser,
  type Character,
  type InsertCharacter,
  type Item,
  type InventoryItem,
  type Quest,
  type CharacterQuest,
  type Enemy,
  type Crew,
  type InsertCrew,
  type CombatLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Character operations
  getCharacter(id: string): Promise<Character | undefined>;
  getCharactersByUserId(userId: string): Promise<Character[]>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacter(id: string, updates: Partial<Character>): Promise<Character>;
  deleteCharacter(id: string): Promise<void>;

  // Inventory operations
  getInventory(characterId: string): Promise<(InventoryItem & { item: Item })[]>;
  addItemToInventory(characterId: string, itemId: string, quantity: number): Promise<InventoryItem>;
  removeItemFromInventory(inventoryId: string): Promise<void>;
  equipItem(inventoryId: string): Promise<void>;
  unequipItem(inventoryId: string): Promise<void>;

  // Quest operations
  getAllQuests(): Promise<Quest[]>;
  getCharacterQuests(characterId: string): Promise<(CharacterQuest & { quest: Quest })[]>;
  startQuest(characterId: string, questId: string): Promise<CharacterQuest>;
  updateQuestProgress(characterQuestId: string, progress: number): Promise<CharacterQuest>;
  completeQuest(characterQuestId: string): Promise<void>;

  // Enemy operations
  getEnemiesByZone(zone: string): Promise<Enemy[]>;
  getEnemy(id: string): Promise<Enemy | undefined>;

  // Crew operations
  getCrew(id: string): Promise<Crew | undefined>;
  getCrewMembers(crewId: string): Promise<Character[]>;
  createCrew(crew: InsertCrew): Promise<Crew>;
  joinCrew(characterId: string, crewId: string): Promise<void>;
  leaveCrew(characterId: string): Promise<void>;

  // Combat operations
  createCombatLog(log: Omit<CombatLog, 'id' | 'createdAt'>): Promise<CombatLog>;
  getCombatHistory(characterId: string): Promise<CombatLog[]>;

  // Item operations
  getItem(id: string): Promise<Item | undefined>;
  getAllItems(): Promise<Item[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Character operations
  async getCharacter(id: string): Promise<Character | undefined> {
    const [character] = await db.select().from(characters).where(eq(characters.id, id));
    return character;
  }

  async getCharactersByUserId(userId: string): Promise<Character[]> {
    return await db.select().from(characters).where(eq(characters.userId, userId));
  }

  async createCharacter(character: InsertCharacter): Promise<Character> {
    // Calculate initial stats based on class
    const classStats = {
      Warrior: { strength: 15, agility: 10, intelligence: 5, vitality: 15, hp: 150, mp: 50 },
      Mage: { strength: 5, agility: 8, intelligence: 18, vitality: 10, hp: 80, mp: 150 },
      Rogue: { strength: 10, agility: 18, intelligence: 8, vitality: 10, hp: 100, mp: 80 },
    };

    const stats = classStats[character.class as keyof typeof classStats];

    const [newCharacter] = await db
      .insert(characters)
      .values({
        ...character,
        strength: stats.strength,
        agility: stats.agility,
        intelligence: stats.intelligence,
        vitality: stats.vitality,
        maxHp: stats.hp,
        currentHp: stats.hp,
        maxMp: stats.mp,
        currentMp: stats.mp,
      })
      .returning();

    return newCharacter;
  }

  async updateCharacter(id: string, updates: Partial<Character>): Promise<Character> {
    const [updated] = await db
      .update(characters)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(characters.id, id))
      .returning();
    return updated;
  }

  async deleteCharacter(id: string): Promise<void> {
    await db.delete(characters).where(eq(characters.id, id));
  }

  // Inventory operations
  async getInventory(characterId: string): Promise<(InventoryItem & { item: Item })[]> {
    const result = await db
      .select()
      .from(inventory)
      .leftJoin(items, eq(inventory.itemId, items.id))
      .where(eq(inventory.characterId, characterId));

    return result.map((row) => ({
      ...row.inventory,
      item: row.items!,
    }));
  }

  async addItemToInventory(characterId: string, itemId: string, quantity: number): Promise<InventoryItem> {
    // Check if item already exists in inventory
    const [existing] = await db
      .select()
      .from(inventory)
      .where(and(eq(inventory.characterId, characterId), eq(inventory.itemId, itemId)));

    if (existing) {
      const [updated] = await db
        .update(inventory)
        .set({ quantity: existing.quantity + quantity })
        .where(eq(inventory.id, existing.id))
        .returning();
      return updated;
    }

    const [newItem] = await db
      .insert(inventory)
      .values({ characterId, itemId, quantity })
      .returning();
    return newItem;
  }

  async removeItemFromInventory(inventoryId: string): Promise<void> {
    await db.delete(inventory).where(eq(inventory.id, inventoryId));
  }

  async equipItem(inventoryId: string): Promise<void> {
    await db.update(inventory).set({ equipped: true }).where(eq(inventory.id, inventoryId));
  }

  async unequipItem(inventoryId: string): Promise<void> {
    await db.update(inventory).set({ equipped: false }).where(eq(inventory.id, inventoryId));
  }

  // Quest operations
  async getAllQuests(): Promise<Quest[]> {
    return await db.select().from(quests);
  }

  async getCharacterQuests(characterId: string): Promise<(CharacterQuest & { quest: Quest })[]> {
    const result = await db
      .select()
      .from(characterQuests)
      .leftJoin(quests, eq(characterQuests.questId, quests.id))
      .where(eq(characterQuests.characterId, characterId));

    return result.map((row) => ({
      ...row.character_quests,
      quest: row.quests!,
    }));
  }

  async startQuest(characterId: string, questId: string): Promise<CharacterQuest> {
    const [quest] = await db
      .insert(characterQuests)
      .values({ characterId, questId })
      .returning();
    return quest;
  }

  async updateQuestProgress(characterQuestId: string, progress: number): Promise<CharacterQuest> {
    const [updated] = await db
      .update(characterQuests)
      .set({ progress })
      .where(eq(characterQuests.id, characterQuestId))
      .returning();
    return updated;
  }

  async completeQuest(characterQuestId: string): Promise<void> {
    await db
      .update(characterQuests)
      .set({ completed: true, claimed: true, completedAt: new Date() })
      .where(eq(characterQuests.id, characterQuestId));
  }

  // Enemy operations
  async getEnemiesByZone(zone: string): Promise<Enemy[]> {
    return await db.select().from(enemies).where(sql`${zone} = ANY(${enemies.zones})`);
  }

  async getEnemy(id: string): Promise<Enemy | undefined> {
    const [enemy] = await db.select().from(enemies).where(eq(enemies.id, id));
    return enemy;
  }

  // Crew operations
  async getCrew(id: string): Promise<Crew | undefined> {
    const [crew] = await db.select().from(crews).where(eq(crews.id, id));
    return crew;
  }

  async getCrewMembers(crewId: string): Promise<Character[]> {
    return await db.select().from(characters).where(eq(characters.crewId, crewId));
  }

  async createCrew(crew: InsertCrew): Promise<Crew> {
    const [newCrew] = await db.insert(crews).values(crew).returning();

    // Update the leader's character to set crewId
    await db
      .update(characters)
      .set({ crewId: newCrew.id })
      .where(eq(characters.id, crew.leaderId));

    return newCrew;
  }

  async joinCrew(characterId: string, crewId: string): Promise<void> {
    await db.update(characters).set({ crewId }).where(eq(characters.id, characterId));

    await db
      .update(crews)
      .set({ memberCount: sql`${crews.memberCount} + 1` })
      .where(eq(crews.id, crewId));
  }

  async leaveCrew(characterId: string): Promise<void> {
    const [character] = await db
      .select()
      .from(characters)
      .where(eq(characters.id, characterId));

    if (character?.crewId) {
      await db.update(characters).set({ crewId: null }).where(eq(characters.id, characterId));

      await db
        .update(crews)
        .set({ memberCount: sql`${crews.memberCount} - 1` })
        .where(eq(crews.id, character.crewId));
    }
  }

  // Combat operations
  async createCombatLog(log: Omit<CombatLog, 'id' | 'createdAt'>): Promise<CombatLog> {
    const [combatLog] = await db.insert(combatLogs).values(log).returning();
    return combatLog;
  }

  async getCombatHistory(characterId: string): Promise<CombatLog[]> {
    return await db
      .select()
      .from(combatLogs)
      .where(
        sql`${combatLogs.attackerId} = ${characterId} OR ${combatLogs.defenderId} = ${characterId}`
      )
      .orderBy(sql`${combatLogs.createdAt} DESC`)
      .limit(50);
  }

  // Item operations
  async getItem(id: string): Promise<Item | undefined> {
    const [item] = await db.select().from(items).where(eq(items.id, id));
    return item;
  }

  async getAllItems(): Promise<Item[]> {
    return await db.select().from(items);
  }
}

export const storage = new DatabaseStorage();
