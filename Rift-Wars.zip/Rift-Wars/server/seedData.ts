import { db } from "./db";
import { items, enemies, quests } from "@shared/schema";

export async function seedGameData() {
  console.log("Checking if game data needs seeding...");

  // Check if data already exists
  const existingItems = await db.select().from(items).limit(1);
  if (existingItems.length > 0) {
    console.log("Game data already seeded");
    return;
  }

  console.log("Seeding game data...");

  // Seed items
  await db.insert(items).values([
    // Weapons
    {
      name: "Plasma Sword",
      type: "weapon",
      rarity: "epic",
      slot: "weapon",
      strengthBonus: 25,
      damage: 40,
      sellValue: 500,
    },
    {
      name: "Neural Blade",
      type: "weapon",
      rarity: "rare",
      slot: "weapon",
      intelligenceBonus: 15,
      damage: 30,
      sellValue: 300,
    },
    {
      name: "Photon Staff",
      type: "weapon",
      rarity: "epic",
      slot: "weapon",
      intelligenceBonus: 30,
      damage: 45,
      sellValue: 600,
    },
    // Armor
    {
      name: "Nano Armor",
      type: "armor",
      rarity: "rare",
      slot: "chest",
      vitalityBonus: 20,
      defense: 25,
      sellValue: 400,
    },
    {
      name: "Cyber Helmet",
      type: "armor",
      rarity: "common",
      slot: "head",
      vitalityBonus: 10,
      defense: 15,
      sellValue: 200,
    },
    {
      name: "Kinetic Boots",
      type: "armor",
      rarity: "rare",
      slot: "boots",
      agilityBonus: 15,
      defense: 18,
      sellValue: 350,
    },
    // Consumables
    {
      name: "Health Pack",
      type: "consumable",
      rarity: "common",
      hpRestore: 100,
      sellValue: 50,
    },
    {
      name: "Energy Cell",
      type: "consumable",
      rarity: "common",
      mpRestore: 50,
      sellValue: 40,
    },
    {
      name: "Nano Stimulant",
      type: "consumable",
      rarity: "rare",
      hpRestore: 250,
      mpRestore: 100,
      sellValue: 150,
    },
    // Accessories
    {
      name: "Cyber Ring",
      type: "accessory",
      rarity: "legendary",
      slot: "accessory",
      strengthBonus: 15,
      intelligenceBonus: 15,
      sellValue: 800,
    },
  ]);

  // Seed enemies
  await db.insert(enemies).values([
    {
      name: "Rogue Droid",
      level: 1,
      hp: 80,
      damage: 10,
      defense: 5,
      xpDrop: 50,
      goldDrop: 20,
      zones: ["nexus_district"],
    },
    {
      name: "Corrupted AI",
      level: 5,
      hp: 200,
      damage: 25,
      defense: 15,
      xpDrop: 150,
      goldDrop: 75,
      zones: ["nexus_district", "industrial_sector"],
    },
    {
      name: "Cyber Hound",
      level: 10,
      hp: 350,
      damage: 40,
      defense: 25,
      xpDrop: 300,
      goldDrop: 150,
      zones: ["industrial_sector"],
    },
    {
      name: "Neural Stalker",
      level: 15,
      hp: 600,
      damage: 65,
      defense: 40,
      xpDrop: 500,
      goldDrop: 250,
      zones: ["data_core", "industrial_sector"],
    },
    {
      name: "Plasma Sentinel",
      level: 20,
      hp: 900,
      damage: 90,
      defense: 60,
      xpDrop: 800,
      goldDrop: 400,
      zones: ["data_core"],
    },
  ]);

  // Seed quests
  const questItems = await db.select().from(items).limit(3);
  
  await db.insert(quests).values([
    {
      title: "Defeat Rogue Droids",
      description: "Clear the Nexus District of hostile rogue droids. The security forces need help maintaining order.",
      requiredLevel: 1,
      objectiveType: "kill",
      targetId: "rogue_droid",
      requiredCount: 10,
      xpReward: 500,
      goldReward: 100,
    },
    {
      title: "Retrieve Data Core",
      description: "Locate and secure the stolen data core from the hacker den in the Industrial Sector.",
      requiredLevel: 5,
      objectiveType: "collect",
      targetId: "data_core_item",
      requiredCount: 1,
      xpReward: 1500,
      goldReward: 500,
      itemRewardId: questItems[0]?.id,
    },
    {
      title: "Hunt Neural Stalkers",
      description: "The Neural Stalkers are becoming a serious threat. Eliminate them to keep the zones safe.",
      requiredLevel: 15,
      objectiveType: "kill",
      targetId: "neural_stalker",
      requiredCount: 5,
      xpReward: 2500,
      goldReward: 800,
      itemRewardId: questItems[1]?.id,
    },
    {
      title: "Explore the Data Core",
      description: "Venture into the mysterious Data Core zone and report your findings.",
      requiredLevel: 20,
      objectiveType: "explore",
      targetId: "data_core",
      requiredCount: 1,
      xpReward: 3000,
      goldReward: 1000,
      itemRewardId: questItems[2]?.id,
    },
  ]);

  console.log("Game data seeded successfully!");
}
