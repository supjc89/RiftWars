import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertCharacterSchema, insertCrewSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Character routes
  app.get('/api/characters', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const characters = await storage.getCharactersByUserId(userId);
      res.json(characters);
    } catch (error) {
      console.error("Error fetching characters:", error);
      res.status(500).json({ message: "Failed to fetch characters" });
    }
  });

  app.get('/api/characters/:id', isAuthenticated, async (req: any, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }
      
      // Verify ownership
      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      res.json(character);
    } catch (error) {
      console.error("Error fetching character:", error);
      res.status(500).json({ message: "Failed to fetch character" });
    }
  });

  app.post('/api/characters', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const data = insertCharacterSchema.parse({ ...req.body, userId });
      const character = await storage.createCharacter(data);
      res.status(201).json(character);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating character:", error);
      res.status(500).json({ message: "Failed to create character" });
    }
  });

  app.patch('/api/characters/:id', isAuthenticated, async (req: any, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      // Verify ownership
      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const updated = await storage.updateCharacter(req.params.id, req.body);
      res.json(updated);
    } catch (error) {
      console.error("Error updating character:", error);
      res.status(500).json({ message: "Failed to update character" });
    }
  });

  app.delete('/api/characters/:id', isAuthenticated, async (req: any, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      // Verify ownership
      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      await storage.deleteCharacter(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting character:", error);
      res.status(500).json({ message: "Failed to delete character" });
    }
  });

  // Inventory routes
  app.get('/api/characters/:id/inventory', isAuthenticated, async (req: any, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const inventory = await storage.getInventory(req.params.id);
      res.json(inventory);
    } catch (error) {
      console.error("Error fetching inventory:", error);
      res.status(500).json({ message: "Failed to fetch inventory" });
    }
  });

  app.post('/api/characters/:id/inventory', isAuthenticated, async (req: any, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const { itemId, quantity } = req.body;
      const inventoryItem = await storage.addItemToInventory(req.params.id, itemId, quantity);
      res.status(201).json(inventoryItem);
    } catch (error) {
      console.error("Error adding item to inventory:", error);
      res.status(500).json({ message: "Failed to add item" });
    }
  });

  app.post('/api/inventory/:id/equip', isAuthenticated, async (req: any, res) => {
    try {
      await storage.equipItem(req.params.id);
      res.status(200).json({ message: "Item equipped" });
    } catch (error) {
      console.error("Error equipping item:", error);
      res.status(500).json({ message: "Failed to equip item" });
    }
  });

  app.post('/api/inventory/:id/unequip', isAuthenticated, async (req: any, res) => {
    try {
      await storage.unequipItem(req.params.id);
      res.status(200).json({ message: "Item unequipped" });
    } catch (error) {
      console.error("Error unequipping item:", error);
      res.status(500).json({ message: "Failed to unequip item" });
    }
  });

  // Quest routes
  app.get('/api/quests', isAuthenticated, async (req, res) => {
    try {
      const quests = await storage.getAllQuests();
      res.json(quests);
    } catch (error) {
      console.error("Error fetching quests:", error);
      res.status(500).json({ message: "Failed to fetch quests" });
    }
  });

  app.get('/api/characters/:id/quests', isAuthenticated, async (req: any, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const quests = await storage.getCharacterQuests(req.params.id);
      res.json(quests);
    } catch (error) {
      console.error("Error fetching character quests:", error);
      res.status(500).json({ message: "Failed to fetch quests" });
    }
  });

  app.post('/api/characters/:id/quests/:questId', isAuthenticated, async (req: any, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const quest = await storage.startQuest(req.params.id, req.params.questId);
      res.status(201).json(quest);
    } catch (error) {
      console.error("Error starting quest:", error);
      res.status(500).json({ message: "Failed to start quest" });
    }
  });

  app.patch('/api/character-quests/:id', isAuthenticated, async (req, res) => {
    try {
      const { progress } = req.body;
      const quest = await storage.updateQuestProgress(req.params.id, progress);
      res.json(quest);
    } catch (error) {
      console.error("Error updating quest progress:", error);
      res.status(500).json({ message: "Failed to update quest" });
    }
  });

  app.post('/api/character-quests/:id/complete', isAuthenticated, async (req: any, res) => {
    try {
      await storage.completeQuest(req.params.id);
      res.status(200).json({ message: "Quest completed" });
    } catch (error) {
      console.error("Error completing quest:", error);
      res.status(500).json({ message: "Failed to complete quest" });
    }
  });

  // Enemy routes
  app.get('/api/enemies/zone/:zone', isAuthenticated, async (req, res) => {
    try {
      const enemies = await storage.getEnemiesByZone(req.params.zone);
      res.json(enemies);
    } catch (error) {
      console.error("Error fetching enemies:", error);
      res.status(500).json({ message: "Failed to fetch enemies" });
    }
  });

  app.get('/api/enemies/:id', isAuthenticated, async (req, res) => {
    try {
      const enemy = await storage.getEnemy(req.params.id);
      if (!enemy) {
        return res.status(404).json({ message: "Enemy not found" });
      }
      res.json(enemy);
    } catch (error) {
      console.error("Error fetching enemy:", error);
      res.status(500).json({ message: "Failed to fetch enemy" });
    }
  });

  // Combat routes
  app.post('/api/characters/:id/combat/pve', isAuthenticated, async (req: any, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const { enemyId } = req.body;
      const enemy = await storage.getEnemy(enemyId);
      if (!enemy) {
        return res.status(404).json({ message: "Enemy not found" });
      }

      // Simple combat calculation
      const playerPower = character.strength + character.agility + character.intelligence;
      const enemyPower = enemy.damage + enemy.defense;
      const playerWins = playerPower > enemyPower || Math.random() > 0.3;

      let xpGain = 0;
      let goldGain = 0;
      let drops: any[] = [];

      if (playerWins) {
        xpGain = enemy.xpDrop;
        goldGain = enemy.goldDrop;

        // Update character
        const newXp = character.experience + xpGain;
        const newGold = character.gold + goldGain;
        const xpNeeded = character.level * 1000;
        let newLevel = character.level;

        if (newXp >= xpNeeded) {
          newLevel = character.level + 1;
        }

        await storage.updateCharacter(character.id, {
          experience: newXp,
          gold: newGold,
          level: newLevel,
        });
      }

      res.json({
        victory: playerWins,
        xpGain,
        goldGain,
        drops,
      });
    } catch (error) {
      console.error("Error in PvE combat:", error);
      res.status(500).json({ message: "Combat failed" });
    }
  });

  app.post('/api/characters/:id/combat/pvp', isAuthenticated, async (req: any, res) => {
    try {
      const attacker = await storage.getCharacter(req.params.id);
      if (!attacker) {
        return res.status(404).json({ message: "Character not found" });
      }

      const userId = req.user.claims.sub;
      if (attacker.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const { defenderId } = req.body;
      const defender = await storage.getCharacter(defenderId);
      if (!defender) {
        return res.status(404).json({ message: "Defender not found" });
      }

      // Combat calculation
      const attackerPower = attacker.strength + attacker.agility + attacker.intelligence;
      const defenderPower = defender.strength + defender.agility + defender.intelligence;
      const attackerWins = attackerPower > defenderPower || Math.random() > 0.4;

      const xpChange = Math.floor(Math.min(attacker.experience, defender.experience) * 0.05);
      const goldChange = Math.floor(Math.random() * 100) + 50;

      if (attackerWins) {
        await storage.updateCharacter(attacker.id, {
          experience: attacker.experience + xpChange,
          gold: attacker.gold + goldChange,
        });
        await storage.updateCharacter(defender.id, {
          experience: Math.max(0, defender.experience - xpChange),
          gold: Math.max(0, defender.gold - goldChange),
        });
      } else {
        await storage.updateCharacter(attacker.id, {
          experience: Math.max(0, attacker.experience - xpChange),
          gold: Math.max(0, attacker.gold - goldChange),
        });
        await storage.updateCharacter(defender.id, {
          experience: defender.experience + xpChange,
          gold: defender.gold + goldChange,
        });
      }

      await storage.createCombatLog({
        attackerId: attacker.id,
        defenderId: defender.id,
        attackerVictory: attackerWins,
        xpChange,
        goldChange,
      });

      res.json({
        victory: attackerWins,
        xpChange,
        goldChange,
      });
    } catch (error) {
      console.error("Error in PvP combat:", error);
      res.status(500).json({ message: "PvP combat failed" });
    }
  });

  app.get('/api/characters/:id/combat-history', isAuthenticated, async (req: any, res) => {
    try {
      const history = await storage.getCombatHistory(req.params.id);
      res.json(history);
    } catch (error) {
      console.error("Error fetching combat history:", error);
      res.status(500).json({ message: "Failed to fetch combat history" });
    }
  });

  // Crew routes
  app.get('/api/crews/:id', isAuthenticated, async (req, res) => {
    try {
      const crew = await storage.getCrew(req.params.id);
      if (!crew) {
        return res.status(404).json({ message: "Crew not found" });
      }
      res.json(crew);
    } catch (error) {
      console.error("Error fetching crew:", error);
      res.status(500).json({ message: "Failed to fetch crew" });
    }
  });

  app.get('/api/crews/:id/members', isAuthenticated, async (req, res) => {
    try {
      const members = await storage.getCrewMembers(req.params.id);
      res.json(members);
    } catch (error) {
      console.error("Error fetching crew members:", error);
      res.status(500).json({ message: "Failed to fetch members" });
    }
  });

  app.post('/api/crews', isAuthenticated, async (req: any, res) => {
    try {
      const data = insertCrewSchema.parse(req.body);
      
      // Verify the character is owned by the user
      const character = await storage.getCharacter(data.leaderId);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const crew = await storage.createCrew(data);
      res.status(201).json(crew);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating crew:", error);
      res.status(500).json({ message: "Failed to create crew" });
    }
  });

  app.post('/api/characters/:id/join-crew/:crewId', isAuthenticated, async (req: any, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      await storage.joinCrew(req.params.id, req.params.crewId);
      res.status(200).json({ message: "Joined crew" });
    } catch (error) {
      console.error("Error joining crew:", error);
      res.status(500).json({ message: "Failed to join crew" });
    }
  });

  app.post('/api/characters/:id/leave-crew', isAuthenticated, async (req: any, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      const userId = req.user.claims.sub;
      if (character.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      await storage.leaveCrew(req.params.id);
      res.status(200).json({ message: "Left crew" });
    } catch (error) {
      console.error("Error leaving crew:", error);
      res.status(500).json({ message: "Failed to leave crew" });
    }
  });

  // Items routes
  app.get('/api/items', isAuthenticated, async (req, res) => {
    try {
      const items = await storage.getAllItems();
      res.json(items);
    } catch (error) {
      console.error("Error fetching items:", error);
      res.status(500).json({ message: "Failed to fetch items" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
